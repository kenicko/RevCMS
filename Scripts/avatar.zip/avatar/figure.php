<?php

	define('BASE', 'http://www.habbo.dk/habbo-imaging/avatarimage?figure=');
	$figure = $_GET['figure'];
	$position = $_GET['position'];

	$src = imagecreatefrompng(BASE . $figure . '&direction=' . 	$position . '&head_direction=' . 	$position);

	imagealphablending($src, true); // alpha blending on
	imagesavealpha($src, true); // save alphablending (important)

	//$dest = imagecreate(54, 65);

	// Copy the shit
	//imagecopy($dest, $src, 0, 0, 6, 8, 54, 51);

	//imagealphablending($dest, true); // alpha blending on
	//imagesavealpha($dest, true); // save alphablending (important)

	header('Content-Type: image/png');

	$outputString = imagepng($src);
	$outputString .= "(c) sulake!"; // copyright shit, should work

	echo $outputString;

	//imagedestroy($dest);
	imagedestroy($src);

?>