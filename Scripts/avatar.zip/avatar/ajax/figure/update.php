<?php
session_start();
header("Content-type: application/json");
# On gender change #
//{"status": "OK", "state": {"hr": "3012-35", "lg": "3018-93", "ch": "3005-62", "hd": "600-1", "sh": "730-95"}, "errors": null, "data": "http://www.habbo.com.tr/habbo-imaging/avatar/ch-3005-62.hd-600-1.hr-3012-35.lg-3018-93.sh-730-95,d-4.h-4,0864381e73a67cebc0ca8d469fe0a488.png"}

# On body part/clothe change #
//{"status": "OK", "errors": null, "data": "http://www.habbo.com.tr/habbo-imaging/avatar/ch-3005-62.hd-625-1.hr-3012-35.lg-3018-93.sh-730-95,d-4.h-4,334fd8c39b7ba0af327df95ed2507be1.png"}
//ch-3111-63-62.hd-3103-1.hr-3163-39.lg-285-77.sh-305-78

# START OF HIDEOUS CODE #

	# Let's set some misc stuff #
	define('FIGURE', 'http://localhost/avatar/figure.php?figure=');

	//Default female figure

	$default['figure']['F']['ch'] = 'ch-3005-62';
	$default['figure']['F']['hd'] = 'hd-600-1';
	$default['figure']['F']['hr'] = 'hr-3012-35';
	$default['figure']['F']['lg'] = 'lg-3018-93';
	$default['figure']['F']['sh'] = 'sh-730-95';

	//Default male figure

	$default['figure']['M']['ch'] = 'ch-3111-63-62';
	$default['figure']['M']['hd'] = 'hd-3103-1';
	$default['figure']['M']['hr'] = 'hr-3163-39';
	$default['figure']['M']['lg'] = 'lg-285-77';
	$default['figure']['M']['sh'] = 'sh-305-78';

	# Start the magic #

	$isGenderBeingChanged = (isset($_POST['gender']) ? true : false);

	if(!$isGenderBeingChanged)
	{

		$data['set_type'] = $_POST['set_type']; // ch, hd, hr, lg, sh - Update figure
		$data['set_id'] = $_POST['set_id']; // e.g. 815-62-62 - Update figure
		$data['posture'] = $_POST['posture']; //d-4.h-4 - Change gender - Update figure
		$data['current_gender'] = $_POST['current_gender']; // Our current gender

		# Current figure parts #

		/**
		 * Head
		 */
		$data['parts']['hd'] = $_POST['hd']; // Head

		/**
		 * Hair
		 */
		$data['parts']['hr'] = $_POST['hr']; // Hair
		$data['parts']['ha'] = $_POST['ha']; // Hair Accessory
		$data['parts']['he'] = $_POST['he']; // Hair E...

		$data['parts']['ea'] = $_POST['ea']; // E...a.. (Glasses etc.)
		$data['parts']['fa'] = $_POST['fa']; // Face Accessory (Beards, etc.)
		$data['parts']['wa'] = $_POST['wa']; // W..a... (Belts, etc.)

		/**
		 * Leg
		 */
		$data['parts']['lg'] = $_POST['lg']; // Leg

		/**
		 * Chest
		 */
		$data['parts']['ch'] = $_POST['ch']; // Chest
		$data['parts']['cp'] = $_POST['cp']; // Chest P.. something
		$data['parts']['cc'] = $_POST['cc']; // Chest Cloth
		$data['parts']['ca'] = $_POST['ca']; // Chest Accessory

		/**
		 * Shoes
		 */
		$data['parts']['sh'] = $_POST['sh']; // Shoes

		/**
		 * Direction
		 */
		$data['parts']['direction'] = $_POST['direction']; // Direction of avatar

		# Let's form our array! #

		// ca, cc, ch,cp, ea, fa, ha, hd, he, hr, lg, sh, wa, (d, h)
		$result = array('status' => 'OK', 'state' => array(
															'ca' => $data['parts']['ca'],
															'cc' => $data['parts']['cc'],
															'ch' => $data['parts']['ch'],
															'cp' => $data['parts']['cp'],
															'ea' => $data['parts']['ea'],
															'fa' => $data['parts']['fa'],
															'ha' => $data['parts']['ha'],
															'hd' => $data['parts']['hd'],
															'he' => $data['parts']['he'],
															'hr' => $data['parts']['hr'],
															'lg' => $data['parts']['lg'],
															'sh' => $data['parts']['sh'],
															'wa' => $data['parts']['wa']
														  ), 'errors' => null, 'data');

		$result['state'][$_POST['set_type']] = $_POST['set_id'];

		foreach($result['state'] as $key => $value)
		{
			if($key == $_POST['set_type'])
			{
				$result['state'][$key] = $_POST['set_id'];
				$finaCode[$key] = $key . '-' . $_POST['set_id'];
			}
			else
			{
				$finaCode[$key] = $key . '-' . $result['state'][$key];
			}
		}

		$result['data'] = FIGURE .
									(($result['state']['ca']) ? $finaCode['ca'] . '.' : '') .
									(($result['state']['cc']) ? $finaCode['cc'] . '.' : '') .
									(($result['state']['ch']) ? $finaCode['ch'] . '.' : '') .
									(($result['state']['cp']) ? $finaCode['cp'] . '.' : '') .
									(($result['state']['ea']) ? $finaCode['ea'] . '.' : '') .
									(($result['state']['fa']) ? $finaCode['fa'] . '.' : '') .
									(($result['state']['ha']) ? $finaCode['ha'] . '.' : '') .
									(($result['state']['hd']) ? $finaCode['hd'] . '.' : '') .
									(($result['state']['he']) ? $finaCode['he'] . '.' : '') .
									(($result['state']['hr']) ? $finaCode['hr'] . '.' : '') .
									(($result['state']['lg']) ? $finaCode['lg'] . '.' : '') .
									(($result['state']['sh']) ? $finaCode['sh'] . '.' : '') .
									(($result['state']['wa']) ? $finaCode['wa'] : '') .
									'&position=' . $data['parts']['direction'];
		//$result['data'] = FIGURE . $finaCode['ch'] . '.' . $finaCode['hd'] . '.' . $finaCode['hr'] . '.' . $finaCode['lg'] . '.' . $finaCode['sh'] . '&position=' . $data['parts']['direction'];


		$_SESSION['figure'][$data['current_gender']] = $result['data'];

		//Some bugs
		unset($result['0']);
		unset($result['state']['']);


		print json_encode($result);
		return;
	}
	else
	{

		# Current figure parts #

		$data['posture'] = $_POST['posture']; //d-4.h-4 - Change gender - Update figure
		$data['gender'] = (($_POST['gender'] == 'F') ? 'F' : 'M'); // F, M - Change gender

		/**
		 * Head
		 */
		$data['parts']['hd'] = $default['figure']['F']['hd']; // Head

		/**
		 * Hair
		 */
		$data['parts']['hr'] = $default['figure']['F']['hr']; // Hair

		/**
		 * Leg
		 */
		$data['parts']['lg'] = $default['figure']['F']['lg']; // Leg

		/**
		 * Chest
		 */
		$data['parts']['ch'] = $default['figure']['F']['ch']; // Chest


		/**
		 * Shoes
		 */
		$data['parts']['sh'] = $default['figure']['F']['sh']; // Shoes

		/**
		 * Direction
		 */
		$data['parts']['direction'] = $_POST['direction']; // Direction of avatar

		if(isset($_SESSION['figure'][$data['gender']]))
		{
			//$result = array('status' => 'OK', 'state' => array('ch' => $data['parts']['ch'], 'hd' => $data['parts']['hd'], 'hr' => $data['parts']['hr'], 'lg' => $data['parts']['lg'], 'sh' => $data['parts']['sh']), 'errors' => null, 'data' => $_SESSION['figure'][$data['gender']]);
			$result = array('status' => 'OK', 'state' => array(
															'ca' => $data['parts']['ca'],
															'cc' => $data['parts']['cc'],
															'ch' => $data['parts']['ch'],
															'cp' => $data['parts']['cp'],
															'ea' => $data['parts']['ea'],
															'fa' => $data['parts']['fa'],
															'ha' => $data['parts']['ha'],
															'hd' => $data['parts']['hd'],
															'he' => $data['parts']['he'],
															'hr' => $data['parts']['hr'],
															'lg' => $data['parts']['lg'],
															'sh' => $data['parts']['sh'],
															'wa' => $data['parts']['wa']
														  ), 'errors' => null, 'data' => $_SESSION['figure'][$data['gender']]);
		}
		else
		{

			//$result = array('status' => 'OK', 'state' => array('ch' => $default['figure'][$_POST['gender']]['ch'], 'hd' => $default['figure'][$_POST['gender']]['hd'], 'hr' => $default['figure'][$_POST['gender']]['hr'], 'lg' => $default['figure'][$_POST['gender']]['lg'], 'sh' => $default['figure'][$_POST['gender']]['sh']), 'errors' => null, 'data');
			$result = array('status' => 'OK', 'state' => array(
															'ca' => $data['parts']['ca'],
															'cc' => $data['parts']['cc'],
															'ch' => $data['parts']['ch'],
															'cp' => $data['parts']['cp'],
															'ea' => $data['parts']['ea'],
															'fa' => $data['parts']['fa'],
															'ha' => $data['parts']['ha'],
															'hd' => $data['parts']['hd'],
															'he' => $data['parts']['he'],
															'hr' => $data['parts']['hr'],
															'lg' => $data['parts']['lg'],
															'sh' => $data['parts']['sh'],
															'wa' => $data['parts']['wa']
														  ), 'errors' => null, 'data');

			// ca, cc, ch,cp, ea, fa, ha, hd, he, hr, lg, sh, wa, (d, h)
			/*$result['data'] = FIGURE .
										$result['state']['ca'] . '.' .
										$result['state']['cc'] . '.' .
										$result['state']['ch'] . '.' .
										$result['state']['cp'] . '.' .
										$result['state']['ea'] . '.' .
										$result['state']['fa'] . '.' .
										$result['state']['ha'] . '.' .
										$result['state']['hd'] . '.' .
										$result['state']['he'] . '.' .
										$result['state']['hr'] . '.' .
										$result['state']['lg'] . '.' .
										$result['state']['sh'] . '.' .
										$result['state']['wa'] . '.' .
										'&position=' . $data['parts']['direction'];*/

			$result['data'] = FIGURE .
										(($result['state']['ca']) ? $result['state']['ca'] . '.' : '') .
										(($result['state']['cc']) ? $result['state']['cc'] . '.' : '') .
										(($result['state']['ch']) ? $result['state']['ch'] . '.' : '') .
										(($result['state']['cp']) ? $result['state']['cp'] . '.' : '') .
										(($result['state']['ea']) ? $result['state']['ea'] . '.' : '') .
										(($result['state']['fa']) ? $result['state']['fa'] . '.' : '') .
										(($result['state']['ha']) ? $result['state']['ha'] . '.' : '') .
										(($result['state']['hd']) ? $result['state']['hd'] . '.' : '') .
										(($result['state']['he']) ? $result['state']['he'] . '.' : '') .
										(($result['state']['hr']) ? $result['state']['hr'] . '.' : '') .
										(($result['state']['lg']) ? $result['state']['lg'] . '.' : '') .
										(($result['state']['sh']) ? $result['state']['sh'] . '.' : '') .
										(($result['state']['wa']) ? $result['state']['wa'] : '') .
										'&position=' . $data['parts']['direction'];


			//$result['data'] = FIGURE . $result['state']['ch'] . '.' . $result['state']['hd'] . '.' . $result['state']['hr'] . '.' . $result['state']['lg'] . '.' . $result['state']['sh'] . '&position=' . $data['parts']['direction'];


			$_SESSION['figure'][$data['gender']] = $result['data'];
		}

		//Some bugs
		unset($result['0']);
		unset($result['state']['']);


		print json_encode($result);
		return;
	}


?>

